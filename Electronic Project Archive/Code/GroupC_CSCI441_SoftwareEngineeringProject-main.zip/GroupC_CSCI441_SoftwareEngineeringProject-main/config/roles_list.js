const roles_list = {
    "Admin": 5150,
    "Vendor": 1984,
    "User": 2001
}

module.exports = roles_list