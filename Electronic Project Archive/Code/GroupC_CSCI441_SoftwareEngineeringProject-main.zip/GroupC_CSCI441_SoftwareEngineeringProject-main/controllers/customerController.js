//written and tested by Pavel Martinez

// controllers customer Controller.js
const pool = require("../db"); // Assuming you have a database connection in db.js

// Function to handle GET request to get all customers
const getAllCustomers = async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM customer");
    res.json(result.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

// Function to handle POST request to create a new customer
const createCustomer = async (req, res) => {
  console.log("Received Body:", req.body); // Debugging line

  if (!req.body || Object.keys(req.body).length === 0) {
    return res.status(400).json({ error: "Request body is empty or missing" });
  }

  const { customername, email, phone, address } = req.body;

  if (!customername || !email || !phone || !address) {
    return res.status(400).json({ error: "Missing required fields" }); //adding Debug Line
  }

  try {
    const result = await pool.query(
      "INSERT INTO customer (customername, email, phone, address) VALUES ($1, $2, $3, $4) RETURNING *",
      [customername, email, phone, address] // Parameters passed as an array
    );
    console.log("Inserted Customer", result.rows[0]);
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error("Database Error:", err.message);
    res.status(500).json({ error: "Internal Server Error" });
  }
};

module.exports = { getAllCustomers, createCustomer };
